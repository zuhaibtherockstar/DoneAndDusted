==============================
     TO-DO APP (Python)
==============================

This is a simple console-based To-Do List application written in Python.

FEATURES:
- View all tasks with status (✔ for done, ✘ for not done)
- Add new tasks
- Remove tasks by number
- Mark tasks as completed
- Error and exception handling for invalid input
- Simple and user-friendly menu

HOW TO USE:
1. Run the program:
   python todo_app.py

2. Choose an option from the menu:
   - 1 to view tasks
   - 2 to add a task
   - 3 to remove a task
   - 4 to mark a task as done
   - 5 to exit the program

3. Follow on-screen instructions to manage your tasks.

NOTES:
- Tasks are stored only during the program runtime.
- Once you exit, the list will reset unless file storage is added.

Enjoy using your To-Do App! 🚀
